#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QDir>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QString appDirPath = QCoreApplication::applicationDirPath();

    // Set the current working directory to the executable's directory
    QDir::setCurrent(appDirPath);

    QQmlApplicationEngine engine;

    engine.load(QUrl(QStringLiteral("digiQclock.qml"))); // Load your main QML file
    return app.exec();
}
