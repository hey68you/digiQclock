#!sh

# This script is meant to demo running by double clicking this .sh script file from the Tracker
cd "$(dirname "$0")"
./DigiQClock --fg 'orange' --bg-start '#211E27' --bg-end '#211E27' --win-title "Orange Clock" &