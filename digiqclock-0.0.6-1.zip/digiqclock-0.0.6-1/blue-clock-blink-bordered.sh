#!sh

# This script is meant to demo running by double clicking this .sh script file from the Tracker
cd "$(dirname "$0")"
./DigiQClock --fg '#AAC1DF' --bg-start '#295078' --bg-end '#1E1B4E' --font DigitalDismay.otf --no-italics --blink-colon --show-border &