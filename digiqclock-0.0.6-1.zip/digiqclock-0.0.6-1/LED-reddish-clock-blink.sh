#!sh

# This script is meant to demo running by double clicking this .sh script file from the Tracker
cd "$(dirname "$0")"
./DigiQClock --fg  '#B40005' --bg-start '#420000' --bg-end '#420000' --no-italics --blink-colon --win-title "Red Clock" &